import os
import asyncio
from dotenv import load_dotenv
from telethon import TelegramClient, events
import google.generativeai as genai

load_dotenv()

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
TARGET_USER_ID = int(os.getenv("TARGET_USER_ID"))
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
SESSION_NAME = os.getenv("SESSION_NAME", "default_sessions2")
GEMINI_PROMPT = os.getenv("GEMINI_PROMPT")

# Check that all key variables are loaded
if not all([API_ID, API_HASH, TARGET_USER_ID, GEMINI_API_KEY]):
    raise ValueError("Error: Not all environment variables (API_ID, API_HASH, TARGET_USER_ID, GEMINI_API_KEY) are set in the .env file.")

client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

try:
    genai.configure(api_key=GEMINI_API_KEY)
    #model = genai.GenerativeModel('learnlm-2.0-flash-experimental')
    model = genai.GenerativeModel('gemma-3n-e4b-it')

    # Create initial history with a system prompt to set the model's behavior.
    # This history will be the start of every new dialogue.
    initial_history = [
        {
            "role": "user",
            "parts": [GEMINI_PROMPT]
        },
        {
            "role": "model",
            "parts": ["Ok, I understand my role. I'm ready."]
        }
    ]
    chat = model.start_chat(history=initial_history)
    print(f"gemma-3n-e4b-it model successfully initialized with prompt: '{GEMINI_PROMPT}'")

except Exception as e:
    print(f"Error initializing Gemini: {e}")
    exit()



@client.on(events.NewMessage)
async def handle_new_message(event):
    """
    This handler is triggered on every new message.
    """
    if event.is_private:
        sender_id = event.message.from_id.user_id

        if sender_id == TARGET_USER_ID:
            message_text = event.message.text
            print(f"Received message from target user (ID: {sender_id}): '{message_text}'")

            async with client.action(event.chat_id, 'typing'):
                try:
                    print("Sending request to Gemini...")
                    response = await chat.send_message_async(message_text)

                    full_response = response.text

                    await event.respond(full_response)

                    print(f"Response from Gemini: '{full_response}'")
                    print("Response successfully sent to the user.")

                except Exception as e:
                    error_message = f""
                    print(error_message)
                    await event.respond(f"")



async def main():
    print("Client is starting...")
    await client.start()

    me = await client.get_me()
    print(f"Logged in as: {me.first_name} {me.last_name or ''} (ID: {me.id})")
    print(f"Bot is active and waiting for messages from user with ID: {TARGET_USER_ID}")

    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
