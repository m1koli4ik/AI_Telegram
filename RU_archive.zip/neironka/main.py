import os
import asyncio
from dotenv import load_dotenv
from telethon import TelegramClient, events
import google.generativeai as genai

load_dotenv()

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
TARGET_USER_ID = int(os.getenv("TARGET_USER_ID"))
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
SESSION_NAME = os.getenv("SESSION_NAME", "default_sessions2") 
GEMINI_PROMPT = os.getenv("GEMINI_PROMPT") 

# Проверяем, что все ключевые переменные загружены
if not all([API_ID, API_HASH, TARGET_USER_ID, GEMINI_API_KEY]):
    raise ValueError("Ошибка: Не все переменные окружения (API_ID, API_HASH, TARGET_USER_ID, GEMINI_API_KEY) заданы в .env файле.")

client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

try:
    genai.configure(api_key=GEMINI_API_KEY)
    #model = genai.GenerativeModel('learnlm-2.0-flash-experimental')
    model = genai.GenerativeModel('gemma-3n-e4b-it') 
    
    # Создаем начальную историю с системным промптом, чтобы задать поведение модели.
    # Эта история будет началом каждого нового диалога.
    initial_history = [
        {
            "role": "user",
            "parts": [GEMINI_PROMPT]
        },
        {
            "role": "model",
            "parts": ["Хорошо, я понял свою роль. Я готов."]
        }
    ]
    chat = model.start_chat(history=initial_history)
    print(f"Модель gemma-3n-e4b-it успешно инициализирована с промптом: '{GEMINI_PROMPT}'")

except Exception as e:
    print(f"Ошибка при инициализации Gemini: {e}")
    exit()



@client.on(events.NewMessage)
async def handle_new_message(event):
    """
    Этот обработчик срабатывает на каждое новое сообщение.
    """
    if event.is_private:
        sender_id = event.message.from_id.user_id
        
        if sender_id == TARGET_USER_ID:
            message_text = event.message.text
            print(f"Получено сообщение от целевого пользователя (ID: {sender_id}): '{message_text}'")

            async with client.action(event.chat_id, 'typing'):
                try:
                    print("Отправка запроса в Gemini...")
                    response = await chat.send_message_async(message_text)
                    
                    full_response = response.text
                    
                    await event.respond(full_response)

                    print(f"Ответ от Gemini: '{full_response}'")
                    print("Ответ успешно отправлен пользователю.")

                except Exception as e:
                    error_message = f""
                    print(error_message)
                    await event.respond(f"")



async def main():
    print("Клиент запускается...")
    await client.start()
    
    me = await client.get_me()
    print(f"Вход выполнен как: {me.first_name} {me.last_name or ''} (ID: {me.id})")
    print(f"Бот активен и ждет сообщений от пользователя с ID: {TARGET_USER_ID}")
    
    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())

